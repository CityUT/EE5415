package com.example.hkdconvertorjava.model;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

public class MainModel {

    public String convertCurrency(String hkdAmount) throws Exception {
        URL url = new URL("https://www.floatrates.com/daily/hkd.json");
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        JSONObject jsonObject = new JSONObject(response.toString());
        JSONObject cnyObject = jsonObject.getJSONObject("cny");
        double rate = cnyObject.getDouble("rate");

        double hkd = Double.parseDouble(hkdAmount);
        double cny = hkd * rate;

        return String.format("%.2f HKD = %.2f CNY\nExchange rate: %.4f", hkd, cny, rate);
    }
}