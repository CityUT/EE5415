package com.example.hkdconvertorjava.viewstate;

public class MainViewState {

    public static class Idle extends MainViewState {}

    public static class Loading extends MainViewState {}

    public static class Success extends MainViewState {
        public final String result;

        public Success(String result) {
            this.result = result;
        }
    }

    public static class Error extends MainViewState {
        public final String error;

        public Error(String error) {
            this.error = error;
        }
    }
}