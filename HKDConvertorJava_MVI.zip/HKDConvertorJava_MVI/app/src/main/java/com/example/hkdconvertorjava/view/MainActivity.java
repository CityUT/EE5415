package com.example.hkdconvertorjava.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

import com.example.hkdconvertorjava.R;
import com.example.hkdconvertorjava.intent.MainIntent;
import com.example.hkdconvertorjava.viewstate.MainViewState;
import com.example.hkdconvertorjava.viewmodel.MainViewModel;

public class MainActivity extends AppCompatActivity {

    private EditText editTextHKD;
    private Button buttonConvert;
    private TextView textViewResult;

    private final MainViewModel mainViewModel = new MainViewModel();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextHKD = findViewById(R.id.editTextHKD);
        buttonConvert = findViewById(R.id.buttonConvert);
        textViewResult = findViewById(R.id.textViewResult);

        mainViewModel.getViewState().observe(this, new Observer<MainViewState>() {
            @Override
            public void onChanged(MainViewState state) {
                if (state instanceof MainViewState.Loading) {
                    textViewResult.setText("Loading...");
                } else if (state instanceof MainViewState.Success) {
                    String result = ((MainViewState.Success) state).result;
                    textViewResult.setText(result);
                } else if (state instanceof MainViewState.Error) {
                    String error = ((MainViewState.Error) state).error;
                    textViewResult.setText("Error: " + error);
                }
            }
        });

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hkdAmount = editTextHKD.getText().toString();
                if (!hkdAmount.isEmpty()) {
                    mainViewModel.processIntent(new MainIntent.ConvertCurrency(hkdAmount));
                } else {
                    textViewResult.setText("Please enter an amount");
                }
            }
        });
    }
}