package com.example.hkdconvertorjava.intent;

public class MainIntent {
    public static class ConvertCurrency {
        public final String hkdAmount;

        public ConvertCurrency(String hkdAmount) {
            this.hkdAmount = hkdAmount;
        }
    }
}