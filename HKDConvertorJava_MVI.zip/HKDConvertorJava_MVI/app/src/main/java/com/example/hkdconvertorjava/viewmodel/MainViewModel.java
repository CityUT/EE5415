package com.example.hkdconvertorjava.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.hkdconvertorjava.intent.MainIntent;
import com.example.hkdconvertorjava.model.MainModel;
import com.example.hkdconvertorjava.viewstate.MainViewState;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainViewModel extends ViewModel {

    private final MainModel mainModel = new MainModel();
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final MutableLiveData<MainViewState> viewState = new MutableLiveData<>(new MainViewState.Idle());

    public LiveData<MainViewState> getViewState() {
        return viewState;
    }

    public void processIntent(MainIntent.ConvertCurrency intent) {
        viewState.setValue(new MainViewState.Loading());

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String result = mainModel.convertCurrency(intent.hkdAmount);
                    viewState.postValue(new MainViewState.Success(result));
                } catch (Exception e) {
                    viewState.postValue(new MainViewState.Error(e.getMessage()));
                }
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        executorService.shutdown();
    }
}